=== Handy Feature Pack ===

License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Special collection of widgets & shortcodes for Handy Theme.

== Installation ==

1. Upload `tz-feature-pack.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0.5 =
* FIXED: PT Member Contact media icons font-size
* NEW: new filter 'handy-redirect-url-after-register' for login/register widget

= 1.0.4 =
* FIXED: Woo_codes shortcode updated with latest versions of Woocommerce
* UPDATE: styles for elements

= 1.0.3 =
* FIXED: Recent Posts Widget output by category
* UPDATE: Mobile styles for elements

= 1.0.2 =
* UPDATE: old contentbuilder compatibility added

= 1.0.1 =
* FIXED: Woo Shortcode Element - fixed products by category ID output
* UPDATE: var_dump() removed from all files

= 1.0.0 =
* Initial Release
